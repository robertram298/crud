<?php
   session_start();
    error_reporting(0);
        date_default_timezone_set("Asia/Kolkata");
         $ses_user = $_SESSION['adminname'];
         $curnt_dt_tm=date("Y-m-d h:i:s");
         $active_record=1;
         $token = md5(rand(1000,9999)); //you can use any encryption
         $_SESSION['token'] = $token;
abstract class PDORepository
{

	const USERNAME="root";
	const PASSWORD="";
	const HOST="localhost";
	const DB="ramu";
	
	protected final function getConnection()
	{
		$connection = null;
		$username = self::USERNAME;
		$password = self::PASSWORD;
		$host = self::HOST;
		$db = self::DB;
		try
		{
			$connection = new PDO("mysql:dbname=$db;host=$host", $username, $password);
			return $connection;
		}
		catch(PDOException $e)
		{
			echo "Error: " . $e->getMessage();
		}
    }

 }
   
  
  ?>