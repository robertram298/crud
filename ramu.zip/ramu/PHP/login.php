<?php
    require_once "common_class.php";
class Login_Details extends PDORepository
{
    public function Stud_login()
    {
        
        $this->Stud_valid();
    }
    private function Stud_valid()
    {		
		$connection = $this->getConnection();
		
        global   $txt_usrname, $txt_pwd;
         $ses_user=1;
        
		$connection->beginTransaction();
		try
        {           

            
                $stud_users_valid = $connection->prepare("SELECT * From stud_users WHERE `user_name`=:txt_usrname AND  `usr_pwd`=:txt_pwd AND `active_record`=1");  

                $stud_users_valid->bindParam(':txt_usrname', $txt_usrname , PDO::PARAM_STR);
                $stud_users_valid->bindParam(':txt_pwd', $txt_pwd, PDO::PARAM_STR);
                $stud_users_valid->execute();
               
			if($stud_users_valid->rowCount() == 1)
			{
                     
               
                //echo "hi998855";exit;  
                
                echo "<script> window.location.replace('student_details.php');</script>";

			}
			else
			{
                
				echo "<script> alert('wrong Password'); </script>";
				echo "<script> window.location='login.php'; </script>";
			}
			
			//echo "hi"; exit;
		}
		catch (PDOException $e)
		{
            
			echo "<script> alert('Error in Data'); </script>";
			echo "<script> window.location='login.php'; </script>";
		}
    }
    

}
$Stud_users = new Login_Details();

    if(isset($_POST['btn_login']))
    {
        //echo "hi"; exit;
        $error = false; 
        $txt_usrname = $master_list->killChars($_POST['txt_usrname']);
        $txt_pwd = $master_list->killChars($_POST['txt_pwd']);
        $fields = array('txt_usrname', 'txt_pwd');
        foreach($fields AS $fieldname) 
        { 
          if(!isset($_POST[$fieldname]) || (trim($_POST[$fieldname])=='')){
            echo 'Field '.$fieldname.' misses !<br />'; 
            $error = true; 
          }
        }
    
        if(!$error)	
        {
            $Stud_users->Stud_login();
            //echo "hi"; exit;
        }
    }
   
    
    require_once "html_headr.php";
?>

 <form method= "POST"  autocomplete="off">
    <div class="container">
        <div class="row">
            <div class="col-sm">
                 <center> <label for="lbl_username">UserName:</label>
                     <input type="text" id="txt_usrname" class="form-control " name="txt_usrname" placeholder="Enter User Name"/>
                    </center>
            </div>
        </div>
        <div class="row">
            <div class="col-sm">
                 <center><label for="lbl_password">Password:</label>
                        <input type="password" class="form-control "id="txt_pwd" name="txt_pwd" placeholder="Password"/></center>
            </div>
        </div>
        <div class="row">
            <div class="col-sm">
                <div class="form-group">
                    <center><button type="submit" class="btn btn-info"  id="btn_login" name="btn_login" >login</button>
                </div>
            </div>
        </div>
        <input type="file" accept="image/*;capture=camera">
        <div class ="row">
             <div class="col-sm">
             <a href="register.php"><p class="text-info">Register Account</a>
             </div>
        </div>
    </div>
</form>
</body>
</html>