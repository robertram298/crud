<?php
//session_start();
require_once "common_class.php";
class StudentDetails extends PDORepository
{
	
	public function StudSave()
    {
		$this->StudInsert();
    }

    private function StudInsert()
    {		
		$connection = $this->getConnection();
		
        global  $st_id, $txt_fname, $txt_lname, $Sci_mark, $Mat_mark,$ipaddress;
        
       //echo $txt_fname.' - '. $txt_lname.' - '. $txt_subject1.' - '. $txt_subject2.' - '.$ipaddress;
       //exit;

		
		 $ses_user=1;
		

		$connection->beginTransaction();
		try
		{
            // insert/update query		
            	
            
                //echo "INSERT INTO `stud_det1`(`fname`, `lname`, `subject1`, `subject2`,`ses_user`,`ip_address`) VALUES ('".$txt_fname."', '". $txt_lname."', '". $txt_subject1."', '". $txt_subject2."',$ses_user,'$ipaddress')";
                //exit;          
                 
                $stud_det_insrt = $connection->prepare(" INSERT INTO `stud_det`( `f_name`, `l_name`, `st_subject1`, `st_subject2`, `ses_user`, `ip_address`) VALUES (:txt_fname, :txt_lname, :Sci_mark, :Mat_mark,:ses_user,:ipaddress )");    

                
			    
			$stud_det_insrt->bindParam(':txt_fname', $txt_fname , PDO::PARAM_STR);
			$stud_det_insrt->bindParam(':txt_lname', $txt_lname , PDO::PARAM_STR);
			$stud_det_insrt->bindParam(':Sci_mark', $Sci_mark , PDO::PARAM_STR);
            $stud_det_insrt->bindParam(':Mat_mark', $Mat_mark , PDO::PARAM_STR);
            $stud_det_insrt->bindParam(':ses_user', $ses_user, PDO::PARAM_INT);
            $stud_det_insrt->bindParam(':ipaddress', $ipaddress , PDO::PARAM_STR);
		
			   
			$stud_det_insrt->execute();
			
             
             
			
			if($stud_det_insrt->rowCount() == 1)
			{
                
             
                //echo "INSERT INTO `stud_det1`(`fname`, `lname`, `subject1`, `subject2`,`ses_user`,`ip_address`) VALUES ('".$txt_fname."', '". $txt_lname."', '". $txt_subject1."', '". $txt_subject2."',$ses_user,'$ipaddress')";
               // exit; 
				$connection->commit();
				echo "<script>alert('Student Details Stored successfully');</script>";
				echo "<script> window.location='simple.php'; </script>";
			}
			else
			{
				$connection->rollBack();
				echo "<script> alert('Error in Data store'); </script>";
				echo "<script> window.location='simple.php'; </script>";
			}
			
		}
		catch (PDOException $e)
		{
			$connection->rollBack();
			echo "<script> alert('Error in Data store'); </script>";
			echo "<script> window.location='simple.php'; </script>";
		}
    }
	
	
}
$Studdet = new StudentDetails();

if(isset($_POST['btn_submit']))
{
	$error = false; 
	
	$txt_fname = $master_list->killChars( $_POST['txt_fname']);
	$txt_lname = $master_list->killChars($_POST['txt_lname']);
	$txt_subject1 =$master_list->killChars ($_POST['txt_subject1']);
	$txt_subject2 = $master_list->killChars($_POST['txt_subject2']);
	
	
	$fields = array('txt_fname', 'txt_lname', 'txt_subject1', 'txt_subject2');
    foreach($fields AS $fieldname) 
    { 
	  if(!isset($_POST[$fieldname]) || (trim($_POST[$fieldname])=='')) {
		echo 'Field '.$fieldname.' misses !<br />'; 
        $error = true; 
      }
	}
	
	if(!$error)	
	{
		$Studdet->StudSave();
	}
}
require_once "html_headr.php";
?>


<form method= "POST">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="label">FName :</label>
                        <div class="input-group">       
                            <input type="text" class="form-control " id="fname" name="txt_fname"  placeholder="First Name" />
                        </div>
                    </div>
                </div>
            
                <div class="col">
                    <div class="form-group">
                        <label for="label1">LName:</label>
                        <div class="input-group">
                            <input type="text" class="form-control " id="lname" name="txt_lname"  placeholder="Last Name"  />
                          
                        </div>
                    </div>
                </div>
                
                <div class="col">
                    <div class="form-group">
                        <label for="lbl_subject1">Science Mark:</label>
                        <div class="input-group">
                            <input type="text" class="form-control add_marks" id="Sci_mark" name="Sci_mark"  placeholder="Science Mark"  />
                        </div>
                    </div>
                </div>
              
                <div class="col">
                    <div class="form-group">
                        <label for="lbl_subject2">Maths Mark:</label>
                        <div class="input-group">
                            <input type="text" class="form-control add_marks" id="Mat_mark" name="Mat_mark"  placeholder="Maths Mark"  />
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="lbl_subject2">English Mark:</label>
                        <div class="input-group">
                            <input type="text" class="form-control add_marks" id="eng_mark" name="eng_mark"  placeholder="English Mark"  />
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="lbl_subject1">Socail Mark:</label>
                        <div class="input-group">
                            <input type="text" class="form-control add_marks" id="social_mark" name="social_mark"  placeholder="Social _Mark"  />
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="lbl_subject2">Tamil Mark:</label>
                        <div class="input-group">
                            <input type="text" class="form-control add_marks" id="tam_mark" name="tam_mark"  placeholder="Tamil Mark"  />
                        </div>
                    </div>
                </div>
                
                <div class="col">
                    <div class="form-group">
                        <label for="lbl_subject2">Total:</label>
                        <div class="input-group">
                            <input type="text" class="form-control " id="total" name="total"  placeholder="Total Mark"  />
                        </div>
                    </div>
                </div>
                </div>
            </div>
</div>
             <div class="row">
               <div class="col">
                <div class="form-group">
                    <center><button type="submit" class="btn btn-outline-primary" name="btn_submit">Login</button></center>
                </div>
            </div>             
        </div>
    </div>

</form>
</body>
</html>
 <script>


$(document).on('keyup', '.add_marks', function( e ) {
    

    var sum = 0;
$('.add_marks').each(function(){
    sum += parseFloat($(this).val());  // Or this.innerHTML, this.innerText
});
    

    $('#total').val( sum);  
		
	});
</script>
