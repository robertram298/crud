<?php
clearstatcache();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");
/*try{
// Connect to the database using a StarSQL ODBC DSN
$master_listh = new PDO("odbc:mssql", 'roh', 'roh123');
// Set SQL query
$sql = "SELECT * FROM Tableminuslock";
// Run query and display results
foreach ($master_listh->query($sql) as $row) {
// Display the data for the first two columns
print $row[0] . ", " . $row[3]. ' - ' . $row[4] . "<br />"; 
}
$master_listh = null;
}catch (PDOException $e) {
print "Error!: " . $e->getMessage();
die();
}*/

ini_set('max_execution_time', 0); // for infinite time of execution 
session_set_cookie_params(0);

session_start();
error_reporting(0);
//error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set("Asia/Kolkata");



$curnt_dt_tm=date("Y-m-d h:i:s");
$active_status='A';

$token = md5(rand(1000,9999)); //you can use any encryption
$_SESSION['token'] = $token;

$errors = array();
$extensions = array("jpeg","jpg","png","pdf");



$ses_akr_usercode = $_SESSION['ses_akr_usercode'];
//$ses_akr_userid = $_SESSION['ses_akr_userid'];
$ses_akr_user_signindttm = $_SESSION['ses_akr_user_signindttm'];
//$_SESSION['ses_akr_usercode'] = $curnt_dt_tm;


$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$rand_str = substr(str_shuffle($permitted_chars), 0, 10);

$projurl=strtok($_SERVER["REQUEST_URI"],'?');
$rmv_url = trim(substr($projurl, strpos($projurl, "akrsupplier/") + 7));


$http_host_pg = 'http://'.$_SERVER['HTTP_HOST'];
$req_uri_pg =  $_SERVER['REQUEST_URI'].'<br />';
$exp_req_uri_pg = explode("/",$req_uri_pg);
$my_path_pg = $http_host_pg.'/'.$exp_req_uri_pg[1].'/'.$exp_req_uri_pg[2].'/';
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$user_ip = $_SERVER['REMOTE_ADDR'];

$host= gethostname();
$remote_ip = gethostbyname($host);


/*function UniqueMachineID($salt = "") {
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        $temp = sys_get_temp_dir().DIRECTORY_SEPARATOR."diskpartscript.txt";
        if(!file_exists($temp) && !is_file($temp)) file_put_contents($temp, "select disk 0\ndetail disk");
        $output = shell_exec("diskpart /s ".$temp);
        $lines = explode("\n",$output);
        $result = array_filter($lines,function($line) {
            return stripos($line,"ID:")!==false;
        });
        if(count($result)>0) {
            $result = array_shift(array_values($result));
            $result = explode(":",$result);
            $result = trim(end($result));       
        } else $result = $output;       
    } else {
        $result = shell_exec("blkid -o value -s UUID");  
        if(stripos($result,"blkid")!==false) {
            $result = $_SERVER['HTTP_HOST'];
        }
    }   
    return md5($salt.md5($result));
}
echo UniqueMachineID();*/


//wmic bios

/*function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
$user_ip=get_client_ip();*/	

// ***************server ip *********************************//
function getAddrByHost($hosts, $timeout = 3) {
  $returnString = '';
  foreach ($hosts as $host) {
    $query = `nslookup -timeout=$timeout -retry=1 $host`;
    if (preg_match('/\nAddress: (.*)\n/', $query, $matches))
      $returnString .= trim($matches[1]);
   
  }
  return $returnString;

}
$hostArray[] = 'http://182.75.10.243:8080/';
//$hostArray[] = 'www.google.com';
$server_ip = getAddrByHost($hostArray);
// ***************server ip *********************************//

ob_start(); // Turn on output buffering
system('ipconfig /all'); //Execute external program to display output
$mycom=ob_get_contents(); // Capture the output into a variable
ob_clean(); // Clean (erase) the output buffer
$findme = "Physical";
$pmac = strpos($mycom, $findme); // Find the position of Physical text
$mac=substr($mycom,($pmac+36),17); // Get Physical Address
//echo $mac;


$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);


/*function UniqueMachineID($salt = "") {  
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {  
          
        $temp = sys_get_temp_dir().DIRECTORY_SEPARATOR."diskpartscript.txt";  
        if(!file_exists($temp) && !is_file($temp)) file_put_contents($temp, "select disk 0\ndetail disk");  
        $output = shell_exec("diskpart /s ".$temp);  
        $lines = explode("\n",$output);  
        $result = array_filter($lines,function($line) {  
            return stripos($line,"ID:")!==false;  
        });  
          
          
        if(count($result)>0) {  
            $result = array_shift(array_values($result));  
            $result = explode(":",$result);  
            $result = trim(end($result));         
        } else $result = $output;         
    } else {  
        $result = shell_exec("blkid -o value -s UUID");    
        if(stripos($result,"blkid")!==false) {  
            $result = $_SERVER['HTTP_HOST'];  
        }  
    }     
    return md5($salt.md5($result));  
}*/

/*$sys = system('dir');*/

$arpmac = shell_exec('arp -a ' . escapeshellarg($user_ip));

//echo $mac = system('ipconfig/all');

/*// PHP code to get the MAC address of Client 
$MAC = exec('getmac'); 
// Storing 'getmac' value in $MAC 
echo $MAC = strtok($MAC, ' '); */
  
  
//echo UniqueMachineID(); 

//echo $hostname;

/*$string=exec('getmac -s '.$user_ip);
$mac=substr($string, 0, 17); 
echo $mac;*/
//$mac = '00.00';

$ipaddress = '{"server_ip":"'.$server_ip.'","remote_ip":"'.$remote_ip.'","user_ip":"'.$user_ip.'","mac":"'.$mac.'-----'.$arpmac.'","machine_name":"'.$hostname.'"}'; //,"comp_unqid":"'.UniqueMachineID().'"

?>