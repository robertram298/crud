<?php
//session_start();
require_once "common_class.php";

class StudentDetails extends PDORepository
{
	
	public function StudSave()
    {
		$this->StudInsert();
    }
    public function Studupdate()
    {     
		$this->StudEdit();
    }

    private function StudInsert()
    {		
		$connection = $this->getConnection();
		
        global  $st_id, $txt_fname, $txt_lname, $num_subject1, $num_subject2,$num_total,$ipaddress;
        
       //echo $txt_fname.' - '. $txt_lname.' - '. $num_subject1.' - '. $num_subject2.' - '.$ipaddress;
       //exit;

		
		 $ses_user=1;
		

		$connection->beginTransaction();
		try
		{
            // insert/update query		
            	
            
                //echo "INSERT INTO `stud_det1`(`fname`, `lname`, `subject1`, `subject2`,`ses_user`,`ip_address`) VALUES ('".$txt_fname."', '". $txt_lname."', '". $num_subject1."', '". $num_subject2."',$ses_user,'$ipaddress')";
                //exit;          
                 
                $stud_det_insrt = $connection->prepare(" INSERT INTO `stud_det`( `f_name`, `l_name`, `st_subject1`, `st_subject2`,`total`, `ses_user`, `ip_address`) VALUES (:txt_fname, :txt_lname, :num_subject1, :num_subject2,:num_total,:ses_user,:ipaddress )");    

                
			    
			$stud_det_insrt->bindParam(':txt_fname', $txt_fname , PDO::PARAM_STR);
			$stud_det_insrt->bindParam(':txt_lname', $txt_lname , PDO::PARAM_STR);
			$stud_det_insrt->bindParam(':num_subject1', $num_subject1 , PDO::PARAM_STR);
            $stud_det_insrt->bindParam(':num_subject2', $num_subject2 , PDO::PARAM_STR);
            $stud_det_insrt->bindParam(':num_total', $num_total , PDO::PARAM_STR);
            $stud_det_insrt->bindParam(':ses_user', $ses_user, PDO::PARAM_INT);
            $stud_det_insrt->bindParam(':ipaddress', $ipaddress , PDO::PARAM_STR);
		
			   
			$stud_det_insrt->execute();
			
             
			
			if($stud_det_insrt->rowCount() == 1)
			{
                
             
                //echo "INSERT INTO `stud_det1`(`fname`, `lname`, `subject1`, `subject2`,`ses_user`,`ip_address`) VALUES ('".$txt_fname."', '". $txt_lname."', '". $num_subject1."', '". $num_subject2."',$ses_user,'$ipaddress')";
               // exit; 
				$connection->commit();
				echo "<script>alert('Student Details Stored successfully');</script>";
				echo "<script> window.location='student_details.php'; </script>";
			}
			else
			{
				$connection->rollBack();
				echo "<script> alert('Error in Data store'); </script>";
				echo "<script> window.location='student_details.php'; </script>";
			}
			
		}
		catch (PDOException $e)
		{
			$connection->rollBack();
			echo "<script> alert('Error in Data store'); </script>";
			echo "<script> window.location='student_details.php'; </script>";
		}
    }
    
    private function StudEdit()
    {		
        $connection = $this->getConnection();
		
        global  $st_id, $txt_fname, $txt_lname, $num_subject1, $num_subject2,$num_total,$ipaddress;
       
        
       //echo $txt_fname.' - '. $txt_lname.' - '. $num_subject1.' - '. $num_subject2.' - '.$ipaddress;
       //exit;
		 $ses_user=1;

		$connection->beginTransaction();
		try
		{
            // insert/update query		
            	
            
           
                $stud_det_edit = $connection->prepare(" UPDATE `stud_det` SET  `f_name` = :txt_fname,`l_name` = :txt_lname,`st_subject1` = :num_subject1,`st_subject2` = :num_subject2,`total` =:num_total WHERE `st_id` = :st_id AND `active_record`=1");    

                $stud_det_edit->bindParam(':st_id', $st_id,PDO::PARAM_INT);
                $stud_det_edit->bindParam(':txt_fname', $txt_fname , PDO::PARAM_STR);
                $stud_det_edit->bindParam(':txt_lname', $txt_lname , PDO::PARAM_STR);
                $stud_det_edit->bindParam(':num_subject1', $num_subject1 , PDO::PARAM_STR);
                $stud_det_edit->bindParam(':num_subject2', $num_subject2 , PDO::PARAM_STR);
                $stud_det_edit->bindParam(':num_total', $num_total , PDO::PARAM_STR);
            
		
			 
			$stud_det_edit->execute();
			   
                  
			
			if($stud_det_edit->rowCount() == 1)
			{
                
             
                
              //echo " UPDATE `stud_det` SET `f_name` ='".$txt_fname."',`l_name` = '".$txt_lname."',`st_subject1` = ".$num_subject1.",`st_subject2` = ".$num_subject2." ,`total` =".$num_total." WHERE `st_id` = ".$st_id." ";
              //exit;  
				$connection->commit();
				echo "<script>alert('Student Details Updated successfully');</script>";
				echo "<script> window.location='student_details.php'; </script>";
			}
			else
			{
				$connection->rollBack();
				echo "<script> alert('Error in Data store'); </script>";
				echo "<script> window.location='student_details.php'; </script>";
			}
			
		}
		catch (PDOException $e)
		{
			$connection->rollBack();
			echo "<script> alert('Error in Data store'); </script>";
			echo "<script> window.location='student_details.php'; </script>";
		}
    }
    
	
	
}
$Studdet = new StudentDetails();



if(isset($_POST['btn_submit']))
{
	$error = false; 
	
	$txt_fname = $master_list->killChars( $_POST['txt_fname']);
	$txt_lname = $master_list->killChars($_POST['txt_lname']);
	$num_subject1 =$master_list->killChars($_POST['num_subject1']);
    $num_subject2 = $master_list->killChars($_POST['num_subject2']);
    $num_total=($_POST['num_total']);
	
	
	$fields = array('txt_fname', 'txt_lname', 'num_subject1', 'num_subject2','num_total');
    foreach($fields AS $fieldname) 
    { 
	  if(!isset($_POST[$fieldname]) || (trim($_POST[$fieldname])=='')) {
		echo 'Field '.$fieldname.' misses !<br />'; 
        $error = true; 
      }
	}
	
	if(!$error)	
	{
		$Studdet->StudSave();
	}
}
if(isset($_POST['btn_update']))
{
	$error = false; 
    
    $st_id = $master_list->killChars( $_POST['txt_update']);
	$txt_fname = $master_list->killChars($_POST['txt_fname']);
	$txt_lname = $master_list->killChars($_POST['txt_lname']);
	$num_subject1 =$master_list->killChars($_POST['num_subject1']);
    $num_subject2 = $master_list->killChars($_POST['num_subject2']);
    $num_total=$master_list->killChars($_POST['num_total']);
	
  
    $fields = array('txt_update','txt_fname', 'txt_lname', 'num_subject1', 'num_subject2','num_total');
    foreach($fields AS $fieldname) 
    { 
	  if(!isset($_POST[$fieldname]) || (trim($_POST[$fieldname])=='')) {
		echo 'Field '.$fieldname.' misses !<br />'; 
        $error = true; 
      }
	}
	

	if(!$error)	
	{
		$Studdet->Studupdate();
	}
}
require_once "html_headr.php";
?>

<form method= "POST"  autocomplete="off">
    <div class="container">
        <div class="row">

            <div class="col">
                <div class="form-group">
                    <label for="label">FName :</label>
                    <div class="input-group">       
                        <input type="text" class="form-control " id="txt_fname" name="txt_fname"  placeholder="First Name" />
                    </div>
                </div>
            </div>
        
            <div class="col">
                <div class="form-group">
                    <label for="label1">LName:</label>
                    <div class="input-group">
                        <input type="text" class="form-control " id="txt_lname" name="txt_lname"  placeholder="Last Name"  />
                        
                    </div>
                </div>
            </div>


            <div class="col">
                <div class="form-group">
                    <label for="lbl_subject1">Science_Mark:</label>
                    <div class="input-group">
                        <input type="text" class="form-control add_marks" id="num_subject1" name="num_subject1" maxlength="4" placeholder="Science Mark"  />
                    </div>
                </div>
            </div>


            <div class="col">
                <div class="form-group">
                    <label for="lbl_subject2">Maths_mark:</label>
                    <div class="input-group">
                        <input type="text" class="form-control add_marks " id="num_subject2" name="num_subject2" maxlength="4" placeholder="MATHS Mark"  />
                    </div>
                </div>
            </div>


            <div class="col">
                <div class="form-group">
                    <label for="lbl_subject2">Total:</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="num_total" name="num_total" readonly="readonly"  placeholder="Total Mark"  />
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="lbl_ph_number">Ph_Number:</label>
                    <div class="input-group">
                        <input type="text" class ="form-control" id="txt_ph_num" name="txt_ph_num" maxlength="10" placeholder="ENTER NUMBER" />
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="lbl_email">EMAIL:</label>
                    <div class="input-group">
                        <input type="email" class ="form-control" id="txt_email" name="txt_email" placeholder="ENTER EMail" />
                    </div>
                </div>
            </div>


        </div>


        <div class="row">
            <div class="col">
                <div class="form-group">
                    <center><button type="submit" class="btn btn-primary"  id="btn_submit" name="btn_submit" >Store</button> 
                    <input type="text" id="txt_update"  name="txt_update" readonly= "readonly" style="display:none;"/>
                    <button type="submit" class="btn btn-success " id="btn_update" name="btn_update" style="display:none;" >Update</button> 
                    <button type="button" class="btn btn-warning" id="btn_reload" name="btn_reload" onClick="history.go(0);">Reload</button>
                </center>
                </div>
            </div> 
        </div>

    </div>

    <?php
        $master_list->Stud_Select($ses_user);
    ?>

</form>
</body>
</html>


<script>
$(document).ready(function(){
  $('#example').dataTable().yadcf([
		//{column_number : 0},
	    {column_number : 1},
	    {column_number : 2},
	    {column_number : 3},
	    {column_number : 4},
        {column_number : 5},
        {column_number : 6},
        {column_number : 7, data: ["active_user", "in-active user"], filter_default_label: "Select user_Type"},
        ]);
});

  


$(document).on('click', '.btn_stu_edit', function( e ){

    var this_id = $.trim($(this).attr("id"));
    var this_id_splt = this_id.split("_");  
    var st_id=$.trim(this_id_splt[2]);  
    //alert(this_id_splt[2]);

    var rq_values = "r_flag=ajx_rq_stud_dets&st_id="+encodeURIComponent(st_id);
		//alert(rq_values); return false;
		$.ajax({
			url: "ajax/ajax_student_details.php",
			type: "post",
			method: "POST",
			data: rq_values ,
			contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
			dataType: "text",
			context: document.body,
			cache: false,
			processData: false,
			statusCode: {
				404: function() {
				  alert( "page not found" );
				}
			},
			xhrFields: {
			  withCredentials: false
			},
			/*beforeSend : function() {
				//this will run before sending an ajax request do what ever activity 
				 //you want like show loaded 
			},*/
			success: function (ramu, status, xhr) {
				//alert(ramu);                 return false;
                $('#txt_fname, #txt_lname, #num_subject1, #num_subject2, #num_total').val('');
                
                //https://stackoverflow.com/questions/10463131/jquery-parsing-json-array
                //var dataArray = [];
                var obj = JSON.parse(ramu);

                $.each(obj, function (index, value) {
                    //dataArray.push([value["yourID"].toString(), value["yourValue"] ]);
                    //alert( value["f_name"] + '-' + value["l_name"] );
                    $('#txt_update').val(value["st_id"]);
                    $('#txt_fname').val(value["f_name"]);
                    $('#txt_lname').val(value["l_name"]);
                    $('#num_subject1').val(value["st_subject1"]);
                    $('#num_subject2').val(value["st_subject2"]);
                    $('#num_total').val(value["total"]);
                    
                });
                    $('#btn_submit').hide();
                    $('#btn_update').show();
                    //alert(this_id);
                    $('.btn_stu_edit').css("visibility", "visible");
                    $('#'+this_id).css("visibility", "hidden");
                    return false;
	
			},
			/*complete : function() {
				//this will run after sending an ajax complete                   
            },*/
			error: function (jqXHR, exception) {
				getErrorMessage(jqXHR, exception);
				//alert(jqXHR + exception);
			}
		});

});

$(document).on('click','.btn_stu_delete',function(e){

    if (confirm('Are you sure you want delete?')) {
        var this_id = $.trim($(this).attr("id"));
        var this_id_splt = this_id.split("_");  
        var st_id=$.trim(this_id_splt[2]); 
        var rq_delete ="r_flag1=ajax_rq_stud_dets_delete&st_id_dlt="+encodeURIComponent(st_id);
        //alert(rq_delete); return false;
        $.ajax({
            url:"ajax/ajax_student_details_delete.php",
            type:"post",
            method:"POST",
            data: rq_delete,
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            datatype: "text",
            context: document.body,
            cache: false,
            processData: false,
            statusCode: {
                404:function(){
                alert("page not found");
                }
            },
            xhrFields: {
                withCredentials: false
            },
            /*beforeSend : function() {
            //this will run before sending an ajax request do what ever activity 
            //you want like show loaded 
            },*/
            success: function (resp,status,xhr) {
                if($.trim(resp) == "Y")
                {
                    alert("it is successfully deleted");
                }
                else{
                    alert("it is not deleted,Try Again");
                }
                window.location.replace("student_details.php");
            },
            error:function (jqXHR,exception){
                 getErrorMessage(jqXHR, exception);
            }
        });

    }
        else{
            window.location.replace("student_details.php");
        }
 });


$(document).on('keyup', '.add_marks', function( e ){
    var sum = 0;
    $('.add_marks').each(function(){
        var this_val = $.trim($(this).val());
        if(parseFloat(this_val)>100 || parseFloat(this_val)<0)
        {
            alert("this value cannot exceed greater than 100 and less than 0");
            location.reload("student_details.php");
        }
        else{
        
        sum += parseFloat(this_val);  
        // Or this.innerHTML, this.innerText
        }
    });
    $('#num_total').val( sum);  
});

</script>