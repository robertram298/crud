<?php

require_once "html_headr.php";
?>
<form method= "POST"  autocomplete="off">
    <div class="container">
        <div class="row">
            <div class="col-sm">
                 <center> <label for="lbl_username">UserName:</label>
                     <input type="text" id="txt_usrname" class="form-control " name="txt_usrname" placeholder="Enter User Name"/>
                    </center>
            </div>
        </div>
        <div class="row">
            <div class="col-sm">
                 <center><label for="lbl_password">Password:</label>
                        <input type="password" class="form-control "id="txt_pwd" name="txt_pwd" placeholder="Password"/></center>
            </div>
        </div>
        <div class="row">
            <div class="col-sm">
                <div class="form-group">
                    <center><button type="submit" class="btn btn-info"  id="btn_login" name="btn_login" >login</button>
                </div>
            </div>
        </div>
    </div>
</form>
</body>
</html>