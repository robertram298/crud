<?php
require_once "config.php";
require_once "get_ipaddr.php";
class Masterlist extends PDORepository
{	
	public function date_converter($datec)
	{
		if($datec=='')
		{
			return NULL;
		}
		else
		{
			$sttm = strtotime($datec);
			$dtcon = date("Y-m-d",$sttm);
			return $dtcon;
		}
	}
	public function date_re_converter($daterc)
	{
		if($daterc=='')
		{
			return NULL;
		}
		else
		{
			$sttmr = strtotime($daterc);
			$dtrcon = date("d-m-Y",$sttmr);
			return $dtrcon;
		}
	}
	
	public function moneyFormatIndia($num) 
	{
		$explrestunits = "" ;
		if(strlen($num)>3) {
			$lastthree = substr($num, strlen($num)-3, strlen($num));
			$restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
			$restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
			$expunit = str_split($restunits, 2);
			for($i=0; $i<sizeof($expunit); $i++) {
				// creates each of the 2's group and adds a comma to the end
				if($i==0) {
					$explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
				} else {
					$explrestunits .= $expunit[$i].",";
				}
			}
			$thecash = $explrestunits.$lastthree;
        } 
        else {
			$thecash = $num;
		}
		return $thecash; // writes the final format where $currency is the currency symbol.
	}
	
	
	function moneyFormatIndian($amount)
    {

        $amount = round($amount,2);

        $amountArray =  explode('.', $amount);
        if(count($amountArray)==1)
        {
            $int = $amountArray[0];
            $des=00;
        }
        else {
            $int = $amountArray[0];
            $des=$amountArray[1];
        }
        if(strlen($des)==1)
        {
            $des=$des."0";
        }
        if($int>=0)
        {
            $int = $this->numFormatIndian( $int );
            $themoney = $int.".".$des;
        }

        else
        {
            $int=abs($int);
            $int = $this->numFormatIndian( $int );
            $themoney= "-".$int.".".$des;
        }   
        return $themoney;
    }

	function numFormatIndian($num)
    {

        $explrestunits = "";
        if(strlen($num)>3)
        {
            $lastthree = substr($num, strlen($num)-3, strlen($num));
            $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
            $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
            $expunit = str_split($restunits, 2);
            for($i=0; $i<sizeof($expunit); $i++) {
                // creates each of the 2's group and adds a comma to the end
                if($i==0) {
                    $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
                } else {
                    $explrestunits .= $expunit[$i].",";
                }
            }
            $thecash = $explrestunits.$lastthree;
        } else {
            $thecash = $num;
        }
        return $thecash; // writes the final format where $currency is the currency symbol.
    }

	/*function formatToInr($number){
        $number=round($number,2);
        // windows is not supported money_format
    if(setlocale(LC_MONETARY, 'en_IN')){
         return money_format('%!'.$decimal.'n', $number);
         }
     else {
        if(floor($number) == $number) {
            $append='.00';
        }else{
            $append='';
        }
        $number = preg_replace("/(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/i", "$1,", $number);
        return $number.$append;
        }
    }*/
	
	public function killChars($strWords)
	{
		$strWords=htmlentities(trim(stripslashes(strip_tags(($strWords)))));
		$badChars = array("alert", ";", "--", "alter","alter routine","create","create routine","create table","create temporary tables","create view","delete","drop","truncate","event","execute","index","insert","lock tables","references","select","show view","trigger","update", "xp_","union","|","&",";","%","'",'"',"\'",'\"',"<>","()","+"); //,"$"  ,"@"
		$newChars = $strWords; 
		for($i=0;$i<count($badChars);$i++)
		{
			$newChars = str_replace($badChars[$i], "",$newChars);
		}		
		str_replace("'", "",str_replace('"', '',strip_tags($newChars)));
		return $newChars; 
	}
	
	public function killCharspwd($strWords)
	{
		$strWords=htmlentities(trim(stripslashes(strip_tags(($strWords)))));
		$badChars = array("alert", ";", "--", "alter","alter routine","create","create routine","create table","create temporary tables","create view","delete","drop","truncate","event","execute","index","insert","lock tables","references","select","show view","trigger","update", "xp_","union","|","&",";","%","'",'"',"\'",'\"',"<>","()","+"); //,"$"  ,"@"
		$newChars = $strWords; 
		for($i=0;$i<count($badChars);$i++)
		{
			$newChars = str_replace($badChars[$i], "",$newChars);
		}		
		str_replace("'", "",str_replace('"', '',strip_tags($newChars)));
		return $newChars; 
	}	
	
	public function Stud_Select($ses_user)
    {		
		$connection = $this->getConnection();
		
		$connection->beginTransaction();
		try
		{
			// insert/update query			
			$stud_det_slt = $connection->prepare("SELECT sd.`st_id`, sd.`f_name` as st_first_name , sd.`l_name` as st_last_name, sd.`st_subject1`, sd.`st_subject2`, sd.`ses_user`,`total`, DATE_FORMAT(sd.`crnt_dt_tm`, '%d-%m-%Y %H:%i:%S') as date_time, sd.`active_record`,(
				CASE 
					WHEN sd.active_record = 1 THEN 'Acitve User'
					WHEN  sd.active_record = 0  THEN 'In-Active User'
				END) as user_type , 
                mf.`first_name` as mf_first_name,mf.`last_name` as mf_last_name, mf.`dept_id`
                FROM `stud_det` as sd 
                INNER JOIN mst_faculty as mf ON sd.ses_user = mf.ft_id 
                WHERE sd.active_record IN (1) AND DATE(sd.`crnt_dt_tm`) = CURDATE() ");			
			
			$stud_det_slt->execute();
			echo "Student Details Report<hr />
			<table border='1' style='border-collapse:collapse;' cellpadding='6' class='display' id='example'>";
			echo "<thead><tr>";
			    echo "<th>S.No.</th>";
				//echo "<th>S.Id</th>";
				echo "<th> Name</th>";
				//echo "<th>Last Name</th>";
				echo "<th>Subject1</th>";
				echo "<th>Subject2</th>";
				echo"<th>Total</th>";
				echo "<th>Session User</th>";
				echo "<th>Date/Time</th>";
				echo "<th>Active Record</th>";
				echo "<th>Action</th>";
				echo "</tr></thead><tbody>";
				$s_no=0;
			while($row = $stud_det_slt->fetch(PDO::FETCH_ASSOC))
			{
				echo "<tr>";
				echo "<td>".(++$s_no).".</td>";
				echo "<td>".$row['st_first_name'].$row['st_last_name']."</td>";
				echo "<td>".$row['st_subject1']."</td>";
				echo "<td>".$row['st_subject2']."</td>";
				echo "<td>".$row['total']."</td>";
				echo "<td>".$row['ses_user'].'-'.$row['mf_first_name']." ".$row['mf_last_name']."-".$row['dept_id']."</td>";
				echo "<td>".$row['date_time']."</td>";
				echo "<td>".(($row['active_record']==1) ? 'active_user' : 'in-active user')."</td>";
				echo '<td><button type="button" class="btn btn-success btn_stu_edit"  id="btn_edit_'.$row["st_id"].'" ><i class="fa fa-edit"></i></button>
				<button type="button" class="btn btn-danger btn_stu_delete" id="btn_delete_'.$row["st_id"].'"><i class="fa fa-trash"></i></button></td>';
				echo "</tr>";
			}
			echo "</tbody></table>";
		}
		catch (PDOException $e)
		{
			$connection->rollBack();
			echo "<script> alert('Error in Data store '); </script>";
		}
		
	}
}
$master_list = new Masterlist();
?>
	