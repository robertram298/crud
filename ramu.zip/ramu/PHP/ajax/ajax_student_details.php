<?php
include_once("../common_class.php");
header('Content-Type: application/json');

$r_flag = $_POST['r_flag'];
$st_id = urldecode($_POST['st_id']);
if(trim($r_flag=='ajx_rq_stud_dets'))
{
class Student_Documents extends PDORepository
{
	public function stud_dets1()
    {
		$connection = $this->getConnection();

		global $st_id;
		try{
				$stud_data_sql = $connection->prepare("SELECT `st_id`, `f_name`, `l_name`, `st_subject1`, `st_subject2`, `total`, `ses_user`, `ip_address`, `crnt_dt_tm`, `active_record`  FROM `stud_det` WHERE `st_id` = ".$st_id." AND active_record=1 limit 1 ");
				$stud_data_sql->execute();
				$results = $stud_data_sql->fetchAll(PDO::FETCH_ASSOC); 
				$json = json_encode($results);
				//echo json_encode($results, JSON_FORCE_OBJECT);
				
			}
			catch (PDOException $e)
		   {
			 echo 'Message: ' .$e->getMessage();
		   }
	}
}
$student_documents = new Student_Documents();

$student_documents->stud_dets1();

}
exit;
?>