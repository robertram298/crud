<?php
include_once("../common_class.php");
//header('Content-Type: application/json');

$r_flag1 = $_POST['r_flag1'];
$st_id_dlt = urldecode($_POST['st_id_dlt']);

if(trim($r_flag1=='ajax_rq_stud_dets_delete'))
{
    class Student_Delete_Documents extends PDORepository
    {
        public function stud_dets_delete1()
        {
            $connection = $this->getConnection();

            global $st_id_dlt;
            $connection->beginTransaction();
            try{
                //echo "UPDATE `stud_det` SET  `active_record`= 0 WHERE `st_id` = ".$st_id_dlt." AND `active_record`=1"; exit;
                $stud_data_sql = $connection->prepare(" UPDATE `stud_det` SET  `active_record`= 0 WHERE `st_id` = :st_id_dlt AND `active_record` = 1");
                
                $stud_data_sql->bindParam(':st_id_dlt', $st_id_dlt,PDO::PARAM_INT);

                $stud_data_sql->execute();
                
                if($stud_data_sql->rowCount()==1)
                {
                    $connection->commit();
                    echo "Y";
                   
                }
                else
                {
                    $connection->rollBack();
                    echo "N";
                    
                }

            }
            catch (PDOException $e)
            {
                echo 'Message: ' .$e->getMessage();
            }
        }
    }
    $student_delete_documents = new Student_Delete_Documents();

$student_delete_documents->stud_dets_delete1();
}
exit;
?>