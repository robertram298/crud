<?php
session_start();  

if(!isset($_SESSION["username"])) {
  header('location: login.php');
  return;
}

require 'db.php';
$id = $_GET['id'];
$sql = 'DELETE FROM people WHERE id=:id';
$statement = $connection->prepare($sql);
if ($statement->execute([':id' => $id])) {
  header("Location: /");
}