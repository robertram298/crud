drop database if exists company;

create database company;

use company;

create table people (
  id  int(11) auto_increment primary key,
  name varchar(30) not null,
  email varchar(30) not null
);

create table users (
  username varchar(30) primary key,
  email varchar(30) not null,
  password varchar(30) not null
);